                                README

Welcome to this release of the Java (TM) Access Bridge for the
Microsoft Windows Operating System!  This release includes 
three Java Access Bridge DLLs, two example applications, and 
documentation of the Java Access Bridge API.

NOTE: This release includes what is needed from the Java
Accessibility Utilities in order to use the Java Access Bridge.  
If you are using JDK 1.1.x, you will also need to obtain the Java 
Foundation Classes version 1.1.  You must use JDK 1.1.8 or later 
if you are using JDK 1.1.x. You must use Java 2 SDK 1.2.2 or later 
if you are using the Java 2 platform.

    To obtain JDK 1.1.x, connect to the following URL:

        http://java.sun.com/products/jdk/1.1

    To obtain the Java 2 SDK, connect to the following URL:

        http://java.sun.com/j2se/

    To obtain the Java Foundation Classes, connect to the 
    following URL:

        http://java.sun.com/products/jfc

This file has three sections:

   - WHAT'S IN THIS RELEASE
   - REDISTRIBUTABLES
   - INSTALLER SOURCE FILES
   - QUICK START


WHAT'S IN THIS RELEASE:
======================

This release contains the following:

AccessBridge-1.0.4\README.txt                    This file.
AccessBridge-1.0.4\binary-license.txt            Software binary license.
AccessBridge-1.0.4\binary-license.html           Software binary license in HTML.
AccessBridge-1.0.4\CHANGES.txt                   Changes since the last 
                                                 release.
AccessBridge-1.0.4\NOTES.txt                     Notes for reviewers.
AccessBridge-1.0.4\access-bridge.jar             The Java language classfile
                                                 for the AccessBridge:
                                           	          DO NOT UNARCHIVE THIS FILE!
AccessBridge-1.0.4\JavaAccessBridge.dll          The AccessBridge DLL invoked 
                                                 by the AccessBridge Java 
                                                 language classfile loaded 
                                                 into the Java Virtual Machine*.
AccessBridge-1.0.4\WindowsAccessBridge.dll       The AccessBridge DLL invoked 
                                                 by the AccessBridge Java 
                                                 language classfile loaded into
                                                 the Java VM.
AccessBridge-1.0.4\JAWTAccessBridge.dll          The AccessBridge DLL invoked 
                                                 by the AccessBridge Java 
                                                 language classfile loaded into
                                                 the Java VM.
AccessBridge-1.0.4\src.zip                       Source to the examples
                                           	 NOTE: You must unzip this file
                                                 before attempting to follow a
                                                 link from the documentation to
                                                 a source file.
AccessBridge-1.0.4\JavaFerret.exe                An example application that uses 
                                                 the Java Accessibility Utilities 
                                                 to examine accessible information 
                                                 about the objects in the Java VM.
AccessBridge-1.0.4\JavaMonkey.exe                An example application that traverses
                                                 the component trees in a particular 
                                                 Java VM and presents the hierarchy
                                                 in a tree view.
AccessBridge-1.0.4\installer                     A directory containing a
                                           	 redistributable installer for
                                           	 the Java Access Bridge and the
                                           	 Java Accessibility Utilities,
                                           	 which are included in 
                                           	 subdirectories.
AccessBridge-1.0.4\docs                          A directory containing documentation
                                           	 in HTML.  The main page is
                                                 AccessBridge-1.0.4\doc\index.html



REDISTRIBUTABLES
================

In keeping with the license agreement for this release of the Java Access Bridge
for the Microsoft Windows Operating System (see binary-license.txt), the
following eight binary files may be redistributed in binary form:

  jaccess-1_1.jar         - in AccessBridge-1.0.4\installer\installerFiles\
  jaccess-1_2.jar         - in AccessBridge-1.0.4\installer\installerFiles\
  jaccess-1_3.jar         - in AccessBridge-1.0.4\installer\installerFiles\
  jaccess-1_4.jar         - in AccessBridge-1.0.4\installer\installerFiles\
  access-bridge.jar       - in AccessBridge-1.0.4\installer\installerFiles\
  JavaAccessBridge.dll    - in AccessBridge-1.0.4\installer\installerFiles\
  WindowsAccessBridge.dll - in AccessBridge-1.0.4\installer\installerFiles\
  JAWTAccessBridge.dll    - in AccessBridge-1.0.4\installer\installerFiles\

In addition, the following example properties file may be redistributed:

 accessibility.properties - in AccessBridge-1.0.4\installer\installerFiles\

INSTALLER SOURCE FILES:
======================
Finally, for purposes of making a custom installer or simply in order
to localize the installer to different languages and/or locales, the source 
files listed below, contained in the AccessBridge-1.0.4\src.zip file, which  
together create the Installer.exe and AccessBridgeTester.class files, may be  
modified and custom binary installers may be built and redistributed from
those files:

  AccessBridgeInstaller.cpp
  AccessBridgeInstaller.h
  AccessBridgeInstallerResource.h
  AccessBridgeInstallerResources.RC
  AccessBridgeTester.java
  

QUICK START:
===========

This section contains quick start directions on setting up the
Java Access Bridge.

The Java Access Bridge includes install.exe, in the 
AccessBridge-1.0.4/installer directory.  The fastest way to get up and 
running is simply to run that installer.  Assuming you have unpacked the 
Java Access Bridge into the C:\AccessBridge-1.0.4 directory, run the 
command:

  C:\AccessBridge-1.0.4\installer\Install

This scans your system for installed Java virtual machines, tests them
to see whether they support the Java Access Bridge, and then allows you
to install the Java Access Bridge into each of those Java virtual machines.

Alternatively, you can modify each Java virtual machine by hand.  Detailed
instructions are in

  C:\AccessBridge-1.0.4\doc\setup.html

To read the Java Access Bridge documentation, view the following 
file from the installed Java Access Bridge in a Web browser:

  C:\AccessBridge-1.0.4\doc\index.html

JavaFerret provides a small sample set of the Java Access Bridge features.
To run JavaFerret after the Access Bridge is installed, follow these steps 
(in either order):

  1. In one window, start any Java application, using the 'java' command
     provided with the JDK.  For example, run the example Simple that
     ships with the Java Foundation Classes.  When the Java application
     runs, the Java VM portion of the Java Access Bridge automatically
     starts.

  2. In a second window, launch the JavaFerret application from the
     C:\AccessBridge-1.0.4 directory.  It automatically starts the 
     Microsoft Windows portion of the Java Access Bridge.  The two
     AccessBridge DLLs find each other and JavaFerret attaches to the
     Simple application.

Please send feedback to access@sun.com.  For more general 
information on Java Accessibility, please refer to the following URL:

        http://www.sun.com/access

--The Java Accessibility Team


Copyright (c) 2003 Sun Microsystems, Inc. All rights reserved.

  Use is subject to license terms.  Third-party software, including font 
  technology, is copyrighted and licensed from Sun suppliers.  Sun,  
  Sun Microsystems,  the Sun logo and  Java are trademarks or registered 
  trademarks of Sun Microsystems, Inc. in the U.S. and other countries.  
  Federal Acquisitions: Commercial Software - Government Users Subject to 
  Standard License Terms and Conditions.  

  Tous droits reserves.  Distribue par des licences qui en restreignent 
  l'utilisation.  Le logiciel detenu par des tiers, et qui comprend la 
  technologie relative aux polices de caracteres, est protege par un copyright 
  et licencie par des fournisseurs de Sun.  Sun, Sun Microsystems, le logo Sun 
  et Java sont des marques de fabrique ou des marques deposees de Sun 
  Microsystems, Inc. aux Etats-Unis et dans d'autres pays.  


*As used in this document, the terms "Java virtual machine" or "JVM" mean 
a virtual machine for the Java platform. 
